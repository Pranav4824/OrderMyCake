//import logo from './logo.svg';
import './App.css';
import { Route, Routes } from 'react-router-dom';
import { Link } from 'react-router-dom';
import LoginComp from './Components/LoginComp';
import CustomerHome from './Home/CustomerHome';
import { useSelector } from 'react-redux';
import LogoutComp from './Components/LogoutComp';
import VendorHome from './Home/VendorHome';
import VendorRegistration from './Registration/VendorRegistration';
import CustomerRegistration from './Registration/CustomerRegistration';
import CorporateRegistration from './Registration/CorporateRegistration';
import CorporateHome from './Home/CorporateHome';
import AdminHome from './Home/AdminHome';
import AddFlavor from './Home/AddFlavor';
import AddProduct from './Home/AddProduct';
import AddShape from './Home/AddShape';

function App() {

  const mystate = useSelector((state)=> state.logged)
  return (
    <div className="App">
      
        <h1 className="bg-primary text-white">Welcome to Order My Cake </h1>
        <div style={{display: mystate.loggedIn?"none":"block"}}>
      <nav className="navbar navbar-expand-sm bg-light mb-3">
        <div className="container-fluid">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link to="/" className="nav-link px-3">Home</Link>
            </li>
            <li className="nav-item">
              <Link to="login" className="nav-link px-3">Login</Link>
            </li>
            <li className="nav-item">
              <Link to="vendorregistration" className="nav-link px-3">Vendor Registeration</Link>
            </li>
            <li className="nav-item">
              <Link to="customerregistration" className="nav-link px-3">Customer Registeration</Link>
            </li>
            <li className="nav-item">
              <Link to="corporateregistration" className="nav-link px-3">Corporate Registeration</Link>
            </li>
          </ul>
        </div>
      </nav>
      </div>
      <Routes>
      <Route path="/login" element={<LoginComp/>}/>
      <Route path="/customer_home" element={<CustomerHome/>}/>
      <Route path="vendorregistration" element={<VendorRegistration/>}/>
      <Route path="customerregistration" element={<CustomerRegistration/>}/>
      <Route path="corporateregistration" element={<CorporateRegistration/>}/>
      <Route path="vendor_home" element={<VendorHome/>}>
          <Route path="Home/addproduct" element={<AddProduct/>}/>
          <Route path="Home/addshape" element={<AddShape/>}/>
      </Route>
      <Route path="corporate_home" element={<CorporateHome/>}/>
      <Route path="/admin_home" element={<AdminHome/>}>
            <Route path="Home/add_flavor" element={<AddFlavor/>}/>
            
            </Route>
      <Route path="/logout" element={<LogoutComp/>}/>
      </Routes>
     
    </div>
  );
}

export default App;
