import { Link } from "react-router-dom";

export default function CorporateHome(){

    return(
    <div>
             <div className="App">
      <div>
        
      </div>
      <nav className="navbar navbar-expand-sm bg-light mb-3">
        <div className="container-fluid">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link to="/" className="nav-link px-3">View Cakes</Link>
            </li>
            <li className="nav-item">
              <Link to="sendrequest" className="nav-link px-3">Send Request</Link>
            </li>
            <li className="nav-item">
              <Link to="/logout" className="nav-link px-3">Logout</Link>
            </li>
          </ul>
          
        </div>
      </nav>
            <h1>Corporate Page</h1>
        </div>
        </div>
   
    )
}