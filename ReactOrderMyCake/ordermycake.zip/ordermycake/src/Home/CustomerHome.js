import { Link } from "react-router-dom";

export default function CustomerHome(){

    return(
    <div>
             <div className="App">
      <div>
        
      </div>
      <nav className="navbar navbar-expand-sm bg-light mb-3">
        <div className="container-fluid">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link to="/" className="nav-link px-3">View Cakes</Link>
            </li>
            <li className="nav-item">
              <Link to="login" className="nav-link px-3">about</Link>
            </li>
            <li className="nav-item">
              <Link to="/logout" className="nav-link px-3">Logout</Link>
            </li>
          </ul>
          
        </div>
      </nav>
            <h1>Customer Page</h1>
        </div>
        </div>
   
    )
}