import { useReducer } from "react";

export default function AddProduct(){


    const init={
        shape:""
      }
    
      const reducer =(state,action)=>{
        switch(action.type){
          case 'update':
            return {...state, [action.fld]: action.val}
          case 'reset':
            return init;
        }
    
      }
      const [info,dispatch]= useReducer(reducer,init);


    return(
        
        <div>
                <form>
     <div className="form-group">
       <label htmlFor="productname">Product Name:</label>
       <input type="text" className="form-control" id="productname" placeholder="Enter Product name" name="productname" value={info.productname.value} 
        onChange={(e)=>{dispatch({type:'update' , fld:'productname', val:e.target.value})}} />
       </div>

       <div className="form-group">
       <label htmlFor="price">Price:</label>
       <input type="number" className="form-control" id="price" placeholder="Enter Price " name="price" value={info.price.value} 
         onChange={(e)=>{dispatch({type:'update' , fld:'price', val:e.target.value})}} />
       </div>

       <div className="form-group">
       <label htmlFor="weight">Weight:</label>
       <input type="number" className="form-control" id="weight" placeholder="Enter Weight " name="weight" value={info.weight.value} 
        onChange={(e)=>{dispatch({type:'update' , fld:'weight', val:e.target.value})}} />
       </div>

       <div className="form-group">
       <label htmlFor="Image">Upload Image </label>
       <input type="file" className="form-control" id="image" placeholder="Upload Image" name="image" value={info.image.value} 
         onChange={(e)=>{dispatch({type:'update' , fld:'image', val:e.target.value})}} />
       </div>

       <div className="form-group">
       <label htmlFor="eggeggless">EggEggless:</label>
       <input type="text" className="form-control" id="eggeggless" placeholder="Enter eggeggless" name="eggeggless" value={info.eggeggless.value} 
        onChange={(e)=>{dispatch({type:'update' , fld:'eggeggless', val:e.target.value})}} />
       </div>
       
       <div className="form-group">
       <label htmlFor="description">Description:</label>
       <textarea cols={6} rows={6} className="form-control" id="description" placeholder="Enter Description" name="description" value={info.description.value} 
         onChange={(e)=>{dispatch({type:'update' , fld:'description', val:e.target.value})}} />
       </div>
       
       
       
       
        </form>
        
                  

        </div>

    )
}