package com.example.demo.entites;

public class CorporateCustomerReg {

	int corporateid;
    String companyname;
    String email;
    String password;
    String regno;
    String contactno;
    String addressline;
	int securityid, areaid;
	String ans;
	
	
	public String getAns() {
		return ans;
	}


	public void setAns(String ans) {
		this.ans = ans;
	}


	public int getSecurityid() {
		return securityid;
	}


	public void setSecurityid(int securityid) {
		this.securityid = securityid;
	}


	public int getAreaid() {
		return areaid;
	}


	public void setAreaid(int areaid) {
		this.areaid = areaid;
	}
	public int getCorporateid() {
		return corporateid;
	}
	public void setCorporateid(int corporateid) {
		this.corporateid = corporateid;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRegno() {
		return regno;
	}
	public void setRegno(String regno) {
		this.regno = regno;
	}
	public String getContactno() {
		return contactno;
	}
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	public String getAddressline() {
		return addressline;
	}
	public void setAddressline(String addressline) {
		this.addressline = addressline;
	}
    
	
	
	
}
